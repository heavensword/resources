//
//  QDRealTimeRecognizeViewController.m
//  QCloudSDKDemo
//
//  Created by Sword on 2019/4/12.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import "QDRealTimeRecognizeViewController.h"
#import <QCloudSDK/QCloudSDK.h>
#import <AVFoundation/AVFoundation.h>
#import "QDAudioDataSource.h"
#import "QDDemoModel.h"
#import "QDDefine.h"
#import "UIView+Toast.h"
#import "QDWaveView.h"

@interface QDRealTimeRecognizeViewController ()<QCloudRealTimeRecognizerDelegate>

@property (nonatomic, strong) QCloudRealTimeRecognizer *realTimeRecognizer;
@property (nonatomic, strong) QDAudioDataSource *dataSource;
@property (nonatomic, assign) BOOL isRecording;
@property (nonatomic, assign) float volume;

@property (weak, nonatomic) IBOutlet UITextView *recognizedTextView;
@property (weak, nonatomic) IBOutlet UISwitch *volumeDetectSwitch;
@property (weak, nonatomic) IBOutlet UISwitch *silenceDetectEndSwitch;
@property (weak, nonatomic) IBOutlet UIButton *recognizeButton;

@property (strong, nonatomic) QDWaveView *recordWaveView;
@property (weak, nonatomic) IBOutlet UILabel *volumeLabel;

@end

@implementation QDRealTimeRecognizeViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    self.navigationItem.title = @"实时语音识别";
    
    _volume = -40;
    __weak typeof(self)weakSelf = self;
    _recordWaveView = [[QDWaveView alloc] initWithFrame:CGRectMake(0, CGRectGetHeight(self.view.bounds)/2.0 - 50.0, CGRectGetWidth(self.view.bounds), 100.0)];
    _recordWaveView.waverLevelCallback = ^(QDWaveView * waver) {
        CGFloat normalizedValue = weakSelf.volume;
        normalizedValue = pow (10, normalizedValue / 40.0);
        weakSelf.recordWaveView.level = normalizedValue;
    };
    _recordWaveView.hidden = YES;
    [self.view addSubview:_recordWaveView];
    
    // Do any additional setup after loading the view.
}

- (void)viewDidLayoutSubviews
{
    _recordWaveView.center = CGPointMake(CGRectGetWidth(self.view.frame) / 2.0, CGRectGetHeight(self.view.frame) / 2.0 - 20);
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self stopRecognizeIfNeed];
}

- (void)stopRecognizeIfNeed
{
    if (_isRecording) {
        _isRecording = NO;
        [_realTimeRecognizer stop];
    }
}
/*
#pragma mark - Navigation
// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/
- (void)startAnimation
{
    [_recordWaveView startAnimation];
}

- (void)stopAnimation
{
    [_recordWaveView stopAnimation];
}

- (void)startRecognizeIfNeed
{
    //    [self startWithRecorder];
    [self updateVolume:NSIntegerMax];
    if (_isRecording) {
        _isRecording = NO;
        [_realTimeRecognizer stop];
    }
    else {
        if (![[AVAudioSession sharedInstance].category isEqualToString:AVAudioSessionCategoryRecord]) {
            NSLog(@"set set audio session category");
            NSError *error = nil;
            [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryRecord error:&error];
            if (error) {
                NSLog(@"error %@", error);
            }
            [[AVAudioSession sharedInstance] setActive:YES error:nil];
        }
        [_realTimeRecognizer start];
    }
}

- (void)startRecognize:(BOOL)didStart
{
    if (didStart) {
        self.recognizedTextView.text = @"";
//        [self.view makeToastActivity:CSToastPositionCenter];
    }
}

- (void)updateButtonTitle
{
    if (_isRecording) {
        [_recognizeButton setTitle:@"停止" forState:UIControlStateNormal];
    }
    else {
        [_recognizeButton setTitle:@"开始" forState:UIControlStateNormal];
    }
}

- (void)updateVolume:(float)volume
{
    if (_volumeDetectSwitch.on && volume <= 0) {
        _volumeLabel.text = [NSString stringWithFormat:@"检测音量%.0lf", volume];
    }
    else {
        _volumeLabel.text = @"检测音量";
    }
}

#pragma mark - QCloudRealTimeRecognizerDelegate
- (void)realTimeRecognizerOnSliceRecognize:(QCloudRealTimeRecognizer *)recognizer
                                  response:(QCloudRealTimeResponse *)response
{
    if (QCloudRealTimeResponseCodeOk == response.code) {
        self.recognizedTextView.text = response.recognizedText;
    }
    NSLog(@"realTimeRecognizerOnSliceRecognize response %@", [response debugDescription]);
}

- (void)realTimeRecognizerDidStartRecord:(QCloudRealTimeRecognizer *)recorder error:(NSError *)error
{
    NSLog(@"realTimeRecognizerDidStartRecord error %@", error);
    if (!error) {
        _isRecording = YES;
        [self startRecognize:YES];
        [self startAnimation];
        [self updateButtonTitle];
    }
}

- (void)realTimeRecognizerDidStopRecord:(QCloudRealTimeRecognizer *)recorder
{
    NSLog(@"realTimeRecognizerDidStopRecord");
    _isRecording = NO;
    [self stopAnimation];
    [self updateButtonTitle];
}

- (void)realTimeRecognizerDidUpdateVolume:(QCloudRealTimeRecognizer *)recognizer volume:(float)volume
{
    NSLog(@"realTimeRecognizerDidUpdateVolume volume:%lf", volume);
    _volume = volume;
    [self updateVolume:volume];
}
/*
 * 检测到flow的开始
 */
- (void)realTimeRecognizerOnFlowStart:(QCloudRealTimeRecognizer *)recognizer voiceId:(NSString *)voiceId seq:(NSInteger)seq;
{
    NSLog(@"realTimeRecognizerFlowStart:%@ seq:%ld", voiceId, seq);
}
/*
 * 检测flow的结束
 */
- (void)realTimeRecognizerOnFlowEnd:(QCloudRealTimeRecognizer *)recognizer voiceId:(NSString *)voiceId seq:(NSInteger)seq;
{
    NSLog(@"realTimeRecognizerFlowEnd:%@ seq:%ld", voiceId, seq);
}

- (void)realTimeRecognizerOnFlowRecognizeStart:(QCloudRealTimeRecognizer *)recognizer voiceId:(NSString *)voiceId seq:(NSInteger)seq
{
    NSLog(@"realTimeRecognizerOnFlowRecognizeStart:%@ seq:%ld", voiceId, seq);
}
/**
 * 检测到flow的结束识别
 * @param voiceId flow对应的voiceId
 * @param seq flow的序列号
 */
- (void)realTimeRecognizerOnFlowRecognizeEnd:(QCloudRealTimeRecognizer *)recognizer voiceId:(NSString *)voiceId seq:(NSInteger)seq
{
    NSLog(@"realTimeRecognizerOnFlowRecognizeEnd:%@ seq:%ld", voiceId, seq);
}

- (void)realTimeRecognizerDidFinish:(QCloudRealTimeRecognizer *)recorder result:(NSString *)result
{
    NSLog(@"realTimeRecognizerDidFinish:%@", result);
}

- (void)realTimeRecognizerDidError:(QCloudRealTimeRecognizer *)recorder error:(NSError *)error
{
    NSLog(@"realTimeRecognizerDidError:%@", error);
}

- (IBAction)onVolumeDetectSwitch:(id)sender
{
     BOOL on = !((UISwitch *)sender).on;
    if (_isRecording) {
        dispatch_async(dispatch_get_main_queue(), ^{
            ((UISwitch *)sender).on = on;
        });
        [self.view makeToast:@"正在识别中，请停止后设置" duration:1.3 position:CSToastPositionCenter];
    }
    else {
        if (!on) {
            [self updateVolume:NSIntegerMax];
        }
        _realTimeRecognizer = nil;
    }
}

- (IBAction)onSilenceEndSwitch:(id)sender
{
    if (_isRecording) {
        BOOL on = !((UISwitch *)sender).on;
        dispatch_async(dispatch_get_main_queue(), ^{
            ((UISwitch *)sender).on = on;
        });
        [self.view makeToast:@"正在识别中，请停止后设置" duration:1.3 position:CSToastPositionCenter];
    }
    else {
        _realTimeRecognizer = nil;
    }
}

- (IBAction)onStartButtonTouched:(id)sender
{
    if (!_realTimeRecognizer) {
        //1.创建QCloudConfig实例
        QCloudConfig *config = [[QCloudConfig alloc] initWithAppId:kQDAppId secretId:kQDSecretId secretKey:kQDSecretKey projectId:kQDProjectId];
        config.sliceTime = 600;                             //语音分片时常600ms
        config.enableDetectVolume = _volumeDetectSwitch.on; //是否检测音量
        config.endRecognizeWhenDetectSilence = _silenceDetectEndSwitch.on; //是否检测到静音停止识别

        //@important: 使用外部数据源传入语音数据，自定义data source需要实现QCloudAudioDataSource协议
//        QCloudDemoAudioDataSource *dataSource = [[QCloudDemoAudioDataSource alloc] init];
//        _realTimeRecognizer = [[QCloudRealTimeRecognizer alloc] initWithConfig:config dataSource:dataSource];
        
        //2.创建QCloudRealTimeRecognizer实例
        _realTimeRecognizer = [[QCloudRealTimeRecognizer alloc] initWithConfig:config];
        
        //3.设置delegate
        _realTimeRecognizer.delegate = self;

    }
    [self startRecognizeIfNeed];
}

@end
