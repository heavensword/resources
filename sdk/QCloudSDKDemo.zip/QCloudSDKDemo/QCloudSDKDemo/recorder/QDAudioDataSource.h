//
//  QCloudDemoAudioDataSource.h
//  QCloudSDKDemo
//
//  Created by Sword on 2019/4/12.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>
#import <QCloudSDK/QCloudSDK.h>

NS_ASSUME_NONNULL_BEGIN

@interface QDAudioDataSource : NSObject<QCloudAudioDataSource>

@end

NS_ASSUME_NONNULL_END
