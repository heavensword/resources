//
//  QCloudAudioRecorderDataSource.m
//  QCloudSDK
//
//  Created by Sword on 2019/4/12.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import "QDAudioDataSource.h"
#import "QDPcmRecorder.h"
#import <AVFoundation/AVFoundation.h>

@interface QDAudioDataSource()<QDPcmRecorderDelegate>

@property (nonatomic, strong) QDPcmRecorder *recorder;
@property (nonatomic, strong) NSMutableData *data;
@property (nonatomic, strong) NSLock *lock;
@property (nonatomic, assign) NSInteger offset;
@property (nonatomic, assign) BOOL recording;

@end

@implementation QDAudioDataSource

@synthesize running = _running;

- (instancetype)init
{
    self = [super init];
    if (self) {
        _data = [[NSMutableData alloc] init];
        _lock = [[NSLock alloc] init];
    }
    return self;
}

- (void)start:(void(^)(BOOL didStart, NSError *error))completion
{
    [self startRecognizeWithRecorder:completion];
}

- (void)stop
{
    _recording = NO;
    _data = nil;
    [_recorder stopRecord];
}

/**
 * SDK会调用此方法读取语音数据，如果缓存的数据不足expectLength字节返回nil
 */
- (NSData *)readData:(NSInteger)expectLength
{
    NSData *data = nil;
//    [_lock lock];
    if ([_data length] >= _offset + expectLength) {
        data = [_data subdataWithRange:NSMakeRange(_offset, expectLength)];
        [_data replaceBytesInRange:NSMakeRange(_offset, expectLength) withBytes:NULL length:0];
        //        NSData *reminData = [_data subdataWithRange:NSMakeRange(expectLength, [_data length] - expectLength)];
        //        [_data setData:reminData];
        //        _offset += expectLength;
    }
//    [_lock unlock];
    return data;
}

- (BOOL)running
{
    return _recording;
}

- (void)__startRecognizeWithRecorder:(void(^)(BOOL didStart, NSError *error))completion
{
    if (!_recorder) {
        _recorder = [[QDPcmRecorder alloc] init];        
        _recorder.delegate = self;
    }
    BOOL result = [_recorder prepareRecord:@"recordaudio.wav"];
    if (result) {
        _recording = YES;
        if (completion) {
            completion(YES, nil);
        }
        _offset = 0;
        _data = [[NSMutableData alloc] init];
        [_recorder startRecord];
    }
}

- (void)startRecognizeWithRecorder:(void(^)(BOOL didStart, NSError *error))completion
{
    NSLog(@"QCloudDemoAudioDataSource startRecognizeWithRecorder");
    
    AVAuthorizationStatus status = [AVCaptureDevice authorizationStatusForMediaType:AVMediaTypeAudio];//麦克风权限
    BOOL granted = NO;
    switch (status) {
        case AVAuthorizationStatusAuthorized:
            granted = YES;
            NSLog(@"QCloudDemoAudioDataSource QCloudMicrophonePermission Authorized");
            break;
        case AVAuthorizationStatusDenied:
            NSLog(@"QCloudDemoAudioDataSource QCloudMicrophonePermission Denied");
            break;
        case AVAuthorizationStatusNotDetermined: {
            NSLog(@"QCloudDemoAudioDataSource QCloudMicrophonePermission not Determined request");
            [AVCaptureDevice requestAccessForMediaType:AVMediaTypeAudio completionHandler:^(BOOL granted) {//麦克风权限
                if (granted) {
                    NSLog(@"QCloudDemoAudioDataSource Authorized");
                    [self __startRecognizeWithRecorder:completion];
                }
                else{
                    NSLog(@"QCloudDemoAudioDataSource QCloudMicrophonePermission Denied or Restricted");
                    NSError *error = [[NSError alloc] initWithDomain:@"QCloudDemoAudioDataSource QCloudMicrophonePermission" code:-1 userInfo:@{@"Reason" : @"please guarantee microphone permission is granted"}];
                    if (completion) {
                        completion(NO, error);
                    }
                }
            }];
            break;
        }
        case AVAuthorizationStatusRestricted:
            NSLog(@"QCloudDemoAudioDataSource QCloudMicrophonePermission Restricted");
            break;
        default:
            break;
    }
    if (granted) {
        [self __startRecognizeWithRecorder:completion];
    }
    else {
        NSError *error = [[NSError alloc] initWithDomain:@"QCloudMicrophonePermission" code:-1 userInfo:@{@"Reason" : @"please guarantee microphone permission is granted"}];
        if (completion) {
            completion(NO, error);
        }
    }
}

- (void)didRecordAudioData:(void * const )bytes length:(NSInteger)length
{
    NSLog(@"QCloudDemoAudioDataSource didRecordAudioData %ld", length);
    //    NSData *audioData = [[NSData alloc] initWithBytes:bytes length:length];
    //    [_datas addObject:audioData];
//    [_lock lock];
    [_data appendBytes:bytes length:length];
//    [_lock unlock];
}

@end
