//
//  QDDefine.h
//  QCloudSDKDemo
//
//  Created by Sword on 2019/4/12.
//  Copyright © 2019 Tencent. All rights reserved.
//

#ifndef QDDefine_h
#define QDDefine_h

#define kQDAppId     @"1258118385"
#define kQDSecretId  @"AKIDv37xZWt0saC5lU6uOjqz4hcKsFBqk3xi"
#define kQDSecretKey @"guZTtzzWZqwpPtr1gFE2cLtnV0gDJwPO"
#define kQDProjectId @"1142255"

#endif /* QDDefine_h */
