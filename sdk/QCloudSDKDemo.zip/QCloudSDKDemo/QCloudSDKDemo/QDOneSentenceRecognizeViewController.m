//
//  ViewController.m
//  QCloudSDKDemo
//
//  Created by Sword on 2019/2/26.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import "QDOneSentenceRecognizeViewController.h"
#import <QCloudSDK/QCloudSDK.h>
#import <AVFoundation/AVFoundation.h>
#import "UIView+Toast.h"
#import "QDDemoModel.h"
#import "QDDefine.h"
#import "QDWaveView.h"

#define kOneSentenceCellIdentifier @"kOneSentenceCellIdentifier"

@interface QDOneSentenceRecognizeViewController ()<QCloudSentenceRecognizerDelegate>

@property (nonatomic, assign) BOOL isRecording;
@property (nonatomic, assign) float volume;
@property (nonatomic, strong) NSArray *dataSource;
@property (nonatomic, strong) QCloudSentenceRecognizer *recognizer;

@property (strong, nonatomic) IBOutlet UITextView *recognizedTextView;
@property (weak,   nonatomic) IBOutlet UITableView *tableView;
@property (strong, nonatomic) QDWaveView *recordWaveView;


@end

@implementation QDOneSentenceRecognizeViewController

- (void)dealloc
{
    _recognizer = nil;
    NSLog(@"QDOneSentenceRecognizeViewController dealloc");
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    self.navigationItem.title = @"一句话识别";
    _dataSource = [QDDemoModel getSentenceModels];
    self.recognizedTextView.text = @"";
    _tableView.tableFooterView = self.recognizedTextView;
    [_tableView registerClass:[UITableViewCell class] forCellReuseIdentifier:kOneSentenceCellIdentifier];
    
    //appid secretId secretKey参数，从腾讯云官网申请
    NSString *appId = kQDAppId;
    NSString *secretId = kQDSecretId;
    NSString *secretKey = kQDSecretKey;    
    
    _recognizer = [[QCloudSentenceRecognizer alloc] initWithAppId:appId secretId:secretId secretKey:secretKey];
    //设置delegate，相关回调方法见QCloudOneSentenceRecognizerDelegate定义
    _recognizer.delegate = self;
    
    // Do any additional setup after loading the view, typically from a nib.
    _volume = -40;
    __weak typeof(self)weakSelf = self;
    _recordWaveView = [[QDWaveView alloc] initWithFrame:CGRectMake(0, CGRectGetHeight(self.view.bounds)/2.0 - 50.0, CGRectGetWidth(self.view.bounds), 100.0)];
    _recordWaveView.waverLevelCallback = ^(QDWaveView * waver) {
        CGFloat normalizedValue = weakSelf.volume;
        normalizedValue = pow (8, normalizedValue / 40.0);
        weakSelf.recordWaveView.level = normalizedValue;
    };
    _recordWaveView.hidden = YES;
    [self.view addSubview:_recordWaveView];
}

- (void)viewDidLayoutSubviews
{
    _recordWaveView.center = CGPointMake(CGRectGetWidth(self.view.frame) / 2.0, CGRectGetHeight(self.view.frame) / 2.0 + 20);
}

- (void)viewWillDisappear:(BOOL)animated
{
    [super viewWillDisappear:animated];
    [self stopRecognizeIfNeed];
  
}

- (void)stopRecognizeIfNeed
{
    if (_isRecording) {
        _isRecording = NO;
        [_recognizer stopRecognizeWithRecorder];
    }
}

- (void)startRecognize:(BOOL)didStart
{
    if (didStart) {
        self.recognizedTextView.text = @"";
        [self.view makeToastActivity:CSToastPositionCenter];
    }
}

- (void)startAnimation
{
    [_recordWaveView startAnimation];
}

- (void)stopAnimation
{
    [_recordWaveView stopAnimation];
}

/**
 * 通过传递语音数据调用一句话识别
 */
- (void)recognizeWithData
{
    //语音数据
    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"recordedFile" ofType:@"wav"];
    NSData *audioData = [[NSData alloc] initWithContentsOfFile:filePath];
    //指定语音数据 语音数据格式 采样率
    BOOL didStart = [_recognizer recoginizeWithData:audioData voiceFormat:kQCloudVoiceFormatWAV frequence:kQCloudEngSerViceType16k];
    [self startRecognize:didStart];
}

/**
 * 通过传递语音url调用一句话识别
 */
- (void)recognizeWithUrl
{    
    //语音数据url
    NSString *url = @"http://liqiansunvoice-1255628450.cosgz.myqcloud.com/30s.wav";
    //指定语音数据url 语音数据格式 采样率
    BOOL didStart = [_recognizer recoginizeWithUrl:url voiceFormat:kQCloudVoiceFormatWAV frequence:kQCloudEngSerViceType16k];
    [self startRecognize:didStart];
}

/**
 * 通过传递自定义参数调用一句话识别
 */
- (void)recognizeWithParams
{
    NSString *url = @"http://liqiansunvoice-1255628450.cosgz.myqcloud.com/30s.wav";
    //获取一个已设置默认参数params
    QCloudSentenceRecognizeParams *params = [_recognizer defaultRecognitionParams];
    
    //通过语音url请求, 此4个参数必须设置
    params.url = url;
    //设置语音频数据格式，见kQCloudVoiceFormat定义
    params.voiceFormat = kQCloudVoiceFormatWAV;
    //设置语音数据来源，见QCloudAudioSourceType定义
    params.sourceType = QCloudAudioSourceTypeUrl;
    //设置采样率，见kQCloudEngSerViceType定义
    params.engSerViceType = kQCloudEngSerViceType16k;
    
    
//    NSString *filePath = [[NSBundle mainBundle] pathForResource:@"test2" ofType:@"wav"];
//    NSData *audioData = [[NSData alloc] initWithContentsOfFile:filePath];
//    //通过语音数据发起请求, 此4个参数必须设置
//    params.data = audioData;
//    params.voiceFormat = kQCloudVoiceFormatWAV;   //kQCloudVoiceFormatWAV or kQCloudVoiceFormatMP3
//    params.sourceType = QCloudAudioSourceTypeAudioData; // QCloudAudioSourceTypeUrl or QCloudAudioSourceTypeAudioData
//    params.engSerViceType = kQCloudEngSerViceType8k; // kQCloudEngSerViceType8k or kQCloudEngSerViceType16k
    
    BOOL didStart = [_recognizer recognizeWithParams:params];
    
    [self startRecognize:didStart];
}

/**
 * 通过传录音器调用一句话识别
 */
- (void)recognizeWithRecorder
{
    if (_isRecording) {
        _isRecording = NO;
        [_recognizer stopRecognizeWithRecorder];
    }
    else {
        if (![[AVAudioSession sharedInstance].category isEqualToString:AVAudioSessionCategoryRecord]) {
            NSLog(@"set set audio session category");
            NSError *error = nil;
            [[AVAudioSession sharedInstance] setCategory:AVAudioSessionCategoryRecord error:&error];
            if (error) {
                NSLog(@"error %@", error);
            }
            [[AVAudioSession sharedInstance] setActive:YES error:nil];
        }
        self.recognizedTextView.text = @"";
        [_recognizer startRecognizeWithRecorder];
    }
}

#pragma mark - QCloudOneSentenceRecognizerDelegate
- (void)oneSentenceRecognizerDidRecognize:(QCloudSentenceRecognizer *)recognizer result:(NSString *)result error:(NSError *)error rawData:(NSDictionary *)rawData
{
    NSString *rawDataString = @"";
    if (rawData) {
        NSData *jsonData = [NSJSONSerialization dataWithJSONObject:rawData options:0 error:nil];
        rawDataString = [[NSString alloc] initWithData:jsonData encoding:NSUTF8StringEncoding];
    }
    NSLog(@"识别结果: %@ error : %@", rawDataString, error);
    self.recognizedTextView.text = rawDataString;
    [self.view hideToastActivity];
}


- (void)oneSentenceRecognizerDidStartRecord:(QCloudSentenceRecognizer *)recognizer error:(NSError *)error
{
    NSLog(@"oneSentenceRecognizerDidStartRecord");
    if (error) {
        NSLog(@"oneSentenceRecognizerDidStartRecord error %@", error);
    }
    else {
        _isRecording = YES;
        [self startAnimation];
        QDDemoModel *model = _dataSource[[_dataSource count] - 1];
        model.recording = _isRecording;
    }
    [_tableView reloadData];
}

- (void)oneSentenceRecognizerDidEndRecord:(QCloudSentenceRecognizer *)recognizer
{
    NSLog(@"oneSentenceRecognizerDidEndRecord");
    _isRecording = NO;
    [self stopAnimation];
    [self startRecognize:YES];
}

- (void)oneSentenceRecognizerDidUpdateVolume:(QCloudSentenceRecognizer *)recognizer volume:(float)volume
{
    NSLog(@"oneSentenceRecognizerDidUpdateVolume %f", volume);  
    _volume = volume;
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView {
    return 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section {
    return [_dataSource count];
}


- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath {
    QDDemoModel *model = _dataSource[indexPath.row];
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:kOneSentenceCellIdentifier forIndexPath:indexPath];
    cell.textLabel.text = model.name;
    if (QDDemoModelSentenceRecorder == model.type) {
        if (model.recording) {
            NSString *highlightText = @"停止录音";
            NSString *text = [NSString stringWithFormat:@"一句话识别(%@)", highlightText];
            NSMutableAttributedString *attributedString = [[NSMutableAttributedString alloc] initWithString:text];
            [attributedString addAttribute:NSForegroundColorAttributeName value:(id)cell.textLabel.textColor.CGColor range:NSMakeRange(0, [text length])];
            [attributedString addAttribute:NSForegroundColorAttributeName value:(id)[UIColor colorWithRed:0 green:142/ 255.0 blue:0 alpha:1.0].CGColor range:NSMakeRange(5, [highlightText length] + 1)];
            cell.textLabel.attributedText = attributedString;
        }
        else {
            cell.textLabel.text = @"一句话识别(开始录音)";
        }
    }
    return cell;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    QDDemoModel *model = _dataSource[indexPath.row];
    switch (model.type) {
        case QDDemoModelSentenceUrl:
            [self recognizeWithUrl];
            break;
        case QDDemoModelSentenceData:
            [self recognizeWithData];
            break;
        case QDDemoModelSentenceCustom:
            [self recognizeWithParams];
            break;
        case QDDemoModelSentenceRecorder: {
            [self recognizeWithRecorder];
            dispatch_after(dispatch_time(DISPATCH_TIME_NOW, (int64_t)(0.1 * NSEC_PER_SEC)), dispatch_get_main_queue(), ^{
                model.recording = self->_isRecording;
                [tableView reloadRowsAtIndexPaths:@[indexPath] withRowAnimation:UITableViewRowAnimationNone];
            });
            break;
        }
        default:
            break;
    }
}
@end
