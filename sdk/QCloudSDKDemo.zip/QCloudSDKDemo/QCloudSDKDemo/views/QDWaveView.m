//
//
//#import "MWWaveView.h"
//
//@interface MWWaveView ()
//
//@property (nonatomic, assign) CGFloat phase;
//@property (nonatomic, assign) CGFloat amplitude;
//@property (nonatomic, assign) CGFloat waveHeight;
//@property (nonatomic, assign) CGFloat waveWidth;
//@property (nonatomic, assign) CGFloat waveMid;
//@property (nonatomic, assign) CGFloat maxAmplitude;
//@property (nonatomic, assign) BOOL didUpdateLevel;
//@property (nonatomic, strong) NSMutableArray * waves;
//@property (nonatomic, strong) CADisplayLink *displayLink;
//
//@end
//
//@implementation MWWaveView
//
//
//- (id)init
//{
//    if(self = [super init]) {
//        [self setup];
//    }
//
//    return self;
//}
//
//- (id)initWithFrame:(CGRect)frame
//{
//    if (self = [super initWithFrame:frame]) {
//        [self setup];
//    }
//
//    return self;
//}
//
//- (void)awakeFromNib
//{
//    [super awakeFromNib];
//    [self setup];
//}
//
//- (void)setup
//{
//    self.opaque = NO;
//    self.waves = [NSMutableArray new];
//
//    self.frequency = 1.2f;
//
//    self.amplitude = 1.0f;
//    self.idleAmplitude = 0.01f;
//
//    self.numberOfWaves = 4;
//    self.phaseShift = -0.05f;
//    self.density = 1.f;
//
//    self.waveColor = [UIColor greenColor];
//    self.mainWaveWidth = 1.5f;
//    self.decorativeWavesWidth = 1.50f;
//
//    self.waveHeight = CGRectGetHeight(self.bounds);
//    self.waveWidth  = CGRectGetWidth(self.bounds);
//    self.waveMid    = self.waveWidth / 2.0f;
//    self.maxAmplitude = self.waveHeight - 4.0f;
//
//}
//- (void)setupDisplayLink
//{
//    _displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(invokeWaveCallback)];
////    _displayLink.preferredFramesPerSecond = 30;
//    [_displayLink addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSRunLoopCommonModes];
//}
//
//- (void)setWaverLevelCallback:(void (^)(MWWaveView * waver))waverLevelCallback
//{
//    _waverLevelCallback = waverLevelCallback;
//
//    [_displayLink invalidate];
//    [self setupDisplayLink];
//}
//
//- (void)invokeWaveCallback
//{
//    self.waverLevelCallback(self);
//}
//
//- (void)setLevel:(CGFloat)level
//{
//    _level = level;
//    self.phase += self.phaseShift; // Move the wave
//    self.amplitude = fmax(level, self.idleAmplitude);
//    _didUpdateLevel = YES;
//    [self setNeedsDisplay];
//}
//
//- (void)drawRect:(CGRect)rect
//{
//    if (!_didUpdateLevel) {
//        return;
//    }
//    self.waveHeight = CGRectGetHeight(self.bounds);
//    self.waveWidth  = CGRectGetWidth(self.bounds);
//    self.waveMid    = self.waveWidth / 2.0f;
//    self.maxAmplitude = self.waveHeight - 4.0f;
//
//    static CGFloat phases[] = {-0.5, 0.5, 0, 1.0};
//    static CGFloat scales[] = {1, 1, 0.5, 0.5, 0.2};
//
////    NSArray *fillColors1 = @[(id)[UIColor colorWithRed:244.0 / 255.0 green:0 blue:110.0 / 255.0 alpha:1.0].CGColor, (id)[UIColor colorWithRed:244.0 / 255.0 green:0 blue:200.0 / 255.0 alpha:0.86].CGColor];
////    NSArray *fillColors2 = @[(id)[UIColor colorWithRed:102.0 / 255.0 green:0 blue:110.0 / 255.0 alpha:1.0].CGColor, (id)[UIColor colorWithRed:102.0 / 255.0 green:0 blue:200.0 / 255.0 alpha:0.86].CGColor];
//
//    NSArray *fillColors1 = @[(id)[UIColor colorWithRed:244.0 / 255.0 green:0 blue:110.0 / 255.0 alpha:1.0].CGColor, (id)[UIColor colorWithRed:244.0 / 255.0 green:0 blue:200.0 / 255.0 alpha:0.86].CGColor];
//    NSArray *fillColors2 = @[(id)[UIColor colorWithRed:102.0 / 255.0 green:0 blue:110.0 / 255.0 alpha:1.0].CGColor, (id)[UIColor colorWithRed:102.0 / 255.0 green:0 blue:200.0 / 255.0 alpha:0.86].CGColor];
//
//    CGFloat phase;
//
//    CGContextRef context = UIGraphicsGetCurrentContext();
//    CGContextSaveGState(context);
//    CGContextClearRect(context, rect);
//    CGContextSetLineWidth(context, 0.0);
//    CGContextSetBlendMode(context, kCGBlendModeColor);
//
//    CGMutablePathRef path1;
//    CGMutablePathRef path2;
//    CGMutablePathRef path3;
//    CGMutablePathRef path4;
//
//    static CGFloat locs[2] = {0.0, 1.0};
//    CGFloat minY = CGFLOAT_MAX;
//    CGFloat maxY = CGFLOAT_MIN;
//    for (NSInteger i = 0; i < self.numberOfWaves; i++) {
//        CGFloat normedAmplitude = scales[i] * self.amplitude;
//        phase = phases[i] * M_PI;
//        CGMutablePathRef path = CGPathCreateMutable();
//        for (CGFloat x = 0; x < self.waveWidth; x += self.density) {
//
//            CGFloat scaling = 1 + -pow(x / self.waveMid - 1, 2); // make center bigger
//            CGFloat A = pow(4 / (4 + pow(x / self.waveWidth, 4.0)), 2.5);
//
//            CGFloat y;
//            if (i == 2 || i == 3) {
//                y = A * scaling * normedAmplitude * self.waveHeight * 0.7 * sin(2 * M_PI * x / self.waveWidth + phase + self.phase) + self.waveHeight * 0.5;
//            }
//            else {
//                y = A * scaling * normedAmplitude * self.waveHeight * 0.4 * sin(2 * M_PI * x / self.waveWidth + phase - self.phase) + self.waveHeight * 0.5;
//            }
//            if (minY > y) {
//                minY = y;
//            }
//            if (maxY < y) {
//                maxY = y;
//            }
//            BOOL firstLine = (0 == x);
//            if (firstLine) {
//                CGPathMoveToPoint(path, NULL, x, y);
//            }
//            else {
//                CGPathAddLineToPoint(path, NULL, x, y);
//            }
//        }
//
////        UIColor *strokeColor = self.waveColor;//[self.waveColor colorWithAlphaComponent:(i == self.numberOfWaves / 2.0 ? 1.0 : 1.0 * multiplier * 0.4)];
////        CGContextSetStrokeColorWithColor(context, strokeColor.CGColor);
////        CGContextAddPath(context, path);
////        CGContextStrokePath(context);
////        CGPathRelease(path);
//
//        if (0 == i) {
//            path1 = path;
//        }
//        else if (1 == i) {
//            path2 = path;
//            CGContextSaveGState(context);
//            CGContextSetFillColorWithColor(context, (CGColorRef)fillColors1[0]);
//            CGMutablePathRef closePath = CGPathCreateMutable();
//            CGPathAddPath(closePath, NULL, path1);
//            CGPathAddPath(closePath, NULL, path2);
//            CGPathCloseSubpath(closePath);
//
//            CGColorSpaceRef mySpace = CGColorSpaceCreateDeviceRGB();
//            CGPoint startPoint = CGPointMake(CGRectGetMidX(rect), minY);
//            CGPoint endPoint = CGPointMake(CGRectGetMidX(rect), maxY);
//            CGGradientRef gradientRef = CGGradientCreateWithColors(mySpace, (CFArrayRef)fillColors1, locs);
//            CGColorSpaceRelease(mySpace);
//
//            CGContextAddPath(context, closePath);
//            CGContextClip(context);
//            CGContextFillRect(context, rect);
//            CGContextDrawLinearGradient(context, gradientRef, startPoint, endPoint, 0);
//            CGGradientRelease(gradientRef);
//
//            CGPathRelease(path1);
//            CGPathRelease(path2);
//            CGPathRelease(closePath);
//            CGContextRestoreGState(context);
//
//            minY = CGFLOAT_MAX;
//            maxY = CGFLOAT_MIN;
//        }
//        else if (2 == i) {
//            path3 = path;
//        }
//        else if (3 == i) {
//            path4 = path;
//            CGContextSaveGState(context);
//
//            CGContextSetFillColorWithColor(context, (CGColorRef)fillColors2[0]);
//            CGMutablePathRef closePath = CGPathCreateMutable();
//            CGPathAddPath(closePath, NULL, path3);
//            CGPathAddPath(closePath, NULL, path4);
//            CGPathCloseSubpath(closePath);
//
//            CGColorSpaceRef mySpace = CGColorSpaceCreateDeviceRGB();
//            CGPoint startPoint = CGPointMake(CGRectGetMidX(rect), minY);
//            CGPoint endPoint = CGPointMake(CGRectGetMidX(rect), maxY);
//            CGGradientRef gradientRef = CGGradientCreateWithColors(mySpace, (CFArrayRef)fillColors2, locs);
//            CGColorSpaceRelease(mySpace);
//
//            CGContextAddPath(context, closePath);
//            CGContextClip(context);
//            CGContextFillRect(context, rect);
//            CGContextDrawLinearGradient(context, gradientRef, startPoint, endPoint, 0);
//            CGGradientRelease(gradientRef);
//
//            CGPathRelease(path3);
//            CGPathRelease(path4);
//            CGPathRelease(closePath);
//            CGContextRestoreGState(context);
//
//            minY = CGFLOAT_MAX;
//            maxY = CGFLOAT_MIN;
//
//        }
//        else {
//            CGPathRelease(path);
//        }
//    }
//    CGContextRestoreGState(context);
//}
//
//- (void)dealloc
//{
//    [_displayLink invalidate];
//}
//
//- (void)startAnimation
//{
//    if (!_displayLink) {
//        [self setupDisplayLink];
//    }
//    else {
//        self.displayLink.paused = NO;
//    }
//    self.hidden = NO;
//}
//
//- (void)stopAnimation
//{
//    self.hidden = YES;
//    self.displayLink.paused = YES;
//}
//
//@end


#import "QDWaveView.h"

@interface QDWaveView ()

@property (nonatomic) CGFloat phase;
@property (nonatomic) CGFloat amplitude;
@property (nonatomic) NSMutableArray * waves;
@property (nonatomic) CGFloat waveHeight;
@property (nonatomic) CGFloat waveWidth;
@property (nonatomic) CGFloat waveMid;
@property (nonatomic) CGFloat maxAmplitude;
@property (nonatomic, strong) CADisplayLink *displayLink;

@end

@implementation QDWaveView

- (void)dealloc
{
    NSLog(@"MWWaveView dealloc");
    [_displayLink invalidate];
}

- (id)init
{
    if(self = [super init]) {
        [self setup];
    }
    
    return self;
}

- (id)initWithFrame:(CGRect)frame
{
    if (self = [super initWithFrame:frame]) {
        [self setup];
    }
    
    return self;
}

- (void)setup
{
    _waves = [NSMutableArray new];
    
    _frequency = 1.2f;
    
    _amplitude = 1.0f;
    _idleAmplitude = 0.01f;
    
    _numberOfWaves = 5;
    _phaseShift = -0.25f;
    _density = 1.f;
    
    _waveColor = [UIColor blueColor];
    _mainWaveWidth = 2.0f;
    _decorativeWavesWidth = 1.0f;
    
    _waveHeight = CGRectGetHeight(self.bounds);
    _waveWidth  = CGRectGetWidth(self.bounds);
    _waveMid    = _waveWidth / 2.0f;
    _maxAmplitude = _waveHeight - 4.0f;
    
    for (int i = 0; i < _numberOfWaves; i++) {
        CAShapeLayer *waveline = [CAShapeLayer layer];
        waveline.lineCap       = kCALineCapButt;
        waveline.lineJoin      = kCALineJoinRound;
        waveline.strokeColor   = [[UIColor blueColor] CGColor];
        waveline.fillColor     = [[UIColor clearColor] CGColor];
        [waveline setLineWidth:(i==0 ? _mainWaveWidth : _decorativeWavesWidth)];
        CGFloat progress = 1.0f - (CGFloat)i / _numberOfWaves;
        CGFloat multiplier = MIN(1.0, (progress / 3.0f * 2.0f) + (1.0f / 3.0f));
        UIColor *color = [_waveColor colorWithAlphaComponent:(i == 0 ? 1.0 : 1.0 * multiplier * 0.4)];
        waveline.strokeColor = color.CGColor;
        [self.layer addSublayer:waveline];
        [_waves addObject:waveline];
    }
}

- (void)setupDisplayLink
{
    [_displayLink invalidate];
    _displayLink = [CADisplayLink displayLinkWithTarget:self selector:@selector(invokeWaveCallback)];
    [_displayLink addToRunLoop:[NSRunLoop currentRunLoop] forMode:NSRunLoopCommonModes];
}

- (void)setWaverLevelCallback:(void (^)(QDWaveView * waver))waverLevelCallback
{
    _waverLevelCallback = waverLevelCallback;
}

- (void)invokeWaveCallback
{
    _waverLevelCallback(self);
}

- (void)setLevel:(CGFloat)level
{
    _level = level;
    
    _phase += _phaseShift; // Move the wave
    
    _amplitude = fmax( level, _idleAmplitude);
    [self updateMeters];
}


- (void)updateMeters
{
    _waveHeight = CGRectGetHeight(self.bounds);
    _waveWidth  = CGRectGetWidth(self.bounds);
    _waveMid    = _waveWidth / 2.0f;
    _maxAmplitude = _waveHeight - 4.0f;
    
//    UIGraphicsBeginImageContext(self.frame.size);
    
    for(int i = 0; i < _numberOfWaves; i++) {
        
        UIBezierPath *wavelinePath = [UIBezierPath bezierPath];
        
        // Progress is a value between 1.0 and -0.5, determined by the current wave idx, which is used to alter the wave's amplitude.
        CGFloat progress = 1.0f - (CGFloat)i / _numberOfWaves;
        CGFloat normedAmplitude = (1.5f * progress - 0.5f) * _amplitude;
        
        
        for(CGFloat x = 0; x < _waveWidth + _density; x += _density) {
            
            //Thanks to https://github.com/stefanceriu/SCSiriWaveformView
            // We use a parable to scale the sinus wave, that has its peak in the middle of the view.
            CGFloat scaling = -pow(x / _waveMid  - 1, 2) + 1; // make center bigger
            
            CGFloat y = scaling * _maxAmplitude * normedAmplitude * sinf(2 * M_PI *(x / _waveWidth) * _frequency + _phase) + (_waveHeight * 0.5);
            
            if (x==0) {
                [wavelinePath moveToPoint:CGPointMake(x, y)];
            }
            else {
                [wavelinePath addLineToPoint:CGPointMake(x, y)];
            }
        }
        
        CAShapeLayer *waveline = [_waves objectAtIndex:i];
        waveline.path = [wavelinePath CGPath];
    }
    
//    UIGraphicsEndImageContext();
}

- (void)startAnimation
{
    if (!_displayLink) {
        [self setupDisplayLink];
    }
    _displayLink.paused = NO;
    self.hidden = NO;
}

- (void)stopAnimation
{
    self.hidden = YES;
    _displayLink.paused = YES;
    [_displayLink invalidate];
    _displayLink = nil;
}
@end
