//
//  QCloudOneSentenceRecognitionParameters.h
//  QCloudSDK
//
//  Created by Sword on 2019/2/26.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import "QCloudCommonParams.h"

NS_ASSUME_NONNULL_BEGIN


@interface QCloudSentenceRecognizeParams : QCloudCommonParams

@property (nonatomic, strong) NSString *subServiceType;         //子服务类型。2，一句话识别。
@property (nonatomic, strong) NSString *engSerViceType;         //引擎类型。8k：电话 8k 通用模型；16k：16k 通用模型。只支持单声道音频识别。
@property (nonatomic, assign) NSInteger sourceType;             //语音数据来源。0：语音 URL；1：语音数据（post body）。
@property (nonatomic, strong) NSString *voiceFormat;            //识别音频的音频格式（支持mp3,wav）。
@property (nonatomic, strong) NSString *usrAudioKey;            //用户端对此任务的唯一标识，用户自助生成，用于用户查找识别结果
@property (nonatomic, strong) NSString *url;                    //语音URL，公网可下载。当 SourceType 值为 0 时须填写该字段，为 1 时不填；URL 的长度大于 0，小于 2048，需进行urlencode编码。音频时间长度要小于60s
@property (nonatomic, strong) NSData *data;                     //语音数据，当SourceType 值为1时必须填写，为0可不写。要base64编码(采用python语言时注意读取文件应该为string而不是byte，以byte格式读取后要decode()。编码后的数据不可带有回车换行符)。音频数据要小于900k

@end

NS_ASSUME_NONNULL_END
