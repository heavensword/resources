echo 开始执行编译脚本

export newVersion="${NumberVersion}""${BrancheName}""${SVN_REVISION}"

echo use PlistBuddy to modify version string.
# /usr/libexec/PlistBuddy -c "Set :CFBundleVersion ${newVersion}" Maxwell／Info.plist
# /usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString ${newVersion}" Maxwell／Info.plist
# /usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString ${newVersion}" Maxwell／Info-R.plist
# /usr/libexec/PlistBuddy -c "Set :CFBundleVersion ${newVersion}" Maxwell／Info-DB.plist
# /usr/libexec/PlistBuddy -c "Set :CFBundleShortVersionString ${newVersion}" Maxwell／Info-DB.plist

echo  "newVersion="${newVersion}" NumberVersion="${NumberVersion}" BrancheName="${BrancheName}"SVN_REVISION="${SVN_REVISION}
echo  "BuildNo="${BuildNo}

CONGRUATION="Release"
#!/usr/bin/env bash

function auto_build() {
	PROJDIR=`pwd`
	PROJECT_BUILDDIR="${PROJDIR}/build"
	#BuildTmpDir="${PROJECT_BUILDDIR}/${PROJECT_NAME}.build/${BUILD_FOLDER}/${PROJECT_NAME}.build"

	#OLD_DIR=$(pwd)
	#NEW_DIR=`pwd`/`dirname $0`
	#cd $NEW_DIR

	SDK=$compileEnv
	# local run example:SDK=iphoneos5.0
	XCODE_PATH=$XCODE_PATH$compileEnv

	# local run example:XCODE_PATH=xcodebuild
	#if [[ "$IS_LOCAL_BUILD" != "1" ]]; then
#    sed -i "" "s#pod.*http://#&$P_USERNAME@#g" Podfile
#    sed -i "" "s#\#source#source#g" Podfile
	#fi
	git config --global credential.helper "store --file $GIT_CREDENTIALS_FILE"
	# pod repo update
#    if [ -e  Podfile.lock ] ;then
#    echo "---rm__Podfile.lock"
#    echo   $scheme
#    echo   scheme

#    rm  Podfile.lock;
#    fi
#    pod_version=`pod --version`
#    echo "before pod version "$pod_version
#    pod update
#    pod_version=`pod --version`
#    echo "after pod version "$pod_version
#    pod install --verbose
#    git config --global --unset credential.helper

#    if ! [ $? = 0 ] ;then
#    exit 1
#    fi

#    if [ "$isOpenTestEnv" = "true" ]; then
#        echo "******打开连接测试环境配置"
#        connect_test_env
#    fi
    cd QCloudSDKDemo
    cd QCloudSDKDemo
#    /usr/libexec/PlistBuddy -c "Set:CFBundleVersion ${BuildNo}" Info-R.plist
	/usr/libexec/PlistBuddy -c "Set:CFBundleVersion ${BuildNo}" Info.plist
#    /usr/libexec/PlistBuddy -c "Set:CFBundleVersion ${BuildNo}" Info-DB.plist

    cd ../
    $XCODE_PATH -scheme QCloudSDKDemo -configuration $CONGRUATION clean -sdk $SDK BUILD_DIR=${PROJECT_BUILDDIR} BUILD_ROOT=${PROJECT_BUILDDIR}


	# warning: Please create a target dailybuildipa, with signing set to com.tencent.*,
	# This uses to match the enterprise certificates


	if [ -e  build/$CONGRUATION-iphoneos/*.ipa ] ;then
		rm -r build/*;
	#cd build/DailyBuild-iphoneos;
	#cd ..
	#rm -r *;
	#cd ..;
	fi

	#if [ -e  result/*.ipa ] ;then
	#rm ./result/*.ipa;
	#fi
	#cd $NEW_DIR

	# OTHER_CFLAGS="-fembed-bitcode"
    $XCODE_PATH -scheme QCloudSDKDemo -configuration $CONGRUATION -sdk $SDK BUILD_DIR=${PROJECT_BUILDDIR} BUILD_ROOT=${PROJECT_BUILDDIR}
	if ! [ $? = 0 ] ;then
	exit 1
	fi

    cd ../
    # build/Release-iphoneos/Maxwell.app
    # compress application.
    mkdir -p build/$CONGRUATION-iphoneos/Payload
    cp -R build/$CONGRUATION-iphoneos/QCloudSDKDemo.app build/$CONGRUATION-iphoneos/Payload
    #/bin/cp -R $CONFIGURATION_BUILD_DIR/QQ.app.dSYM $CONFIGURATION_BUILD_DIR/Payload
    #/bin/cp images/logo_itunes.png $CONFIGURATION_BUILD_DIR/iTunesArtwork
    cd build/$CONGRUATION-iphoneos/
    # zip up the QQ directory
    zip -r QCloudSDKDemo.ipa Payload
    echo "build="${build}${BaseLine}
    cd ../../

    #cd $OLD_DIR
    if [ -e  result ] ;then
    rm -r result;
    fi
    mkdir -p result;

    cp build/$CONGRUATION-iphoneos/*.ipa result/${BaseLine}.ipa
}

# -------------------------
# 功能：  打开连接测试环境
# 参数：  无
# 返回值：无
# -------------------------
function connect_test_env()
{
    # 去掉QQMSFContact_Prefix.pch 中的 //#define MSFT_FUNCTION 的前面注释符
    sed -i '' 's/\/\/#define INTERNAL_TEST/#define INTERNAL_TEST/' 'QCloudSDKDemo/PrefixHeader.pch'
    
    if [ $? != 0 ]; then
        echo "打开连接测试环境配置失败"
        exit 1
    fi
}

auto_build

