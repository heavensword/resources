//
//  QCloudConfig.h
//  QCloudSDK
//
//  Created by Sword on 2019/3/29.
//  Copyright © 2019 Tencent. All rights reserved.
//

#import <Foundation/Foundation.h>

NS_ASSUME_NONNULL_BEGIN

@interface QCloudConfig : NSObject

//通用配置参数
@property (nonatomic, strong, readonly) NSString *appId;        //腾讯云appId     基本概念见https://cloud.tencent.com/document/product/441/6194
@property (nonatomic, strong, readonly) NSString *secretId;     //腾讯云secretId  基本概念见https://cloud.tencent.com/document/product/441/6194
@property (nonatomic, strong, readonly) NSString *secretKey;    //腾讯云secretKey 基本概念见https://cloud.tencent.com/document/product/441/6194
@property (nonatomic, strong, readonly) NSString *projectId;    //腾讯云projectId 基本概念见https://cloud.tencent.com/document/product/441/6194

//实时语音识别相关参数
@property (nonatomic, assign) BOOL usingSSL;                            //默认NO 是否使用https，由于NSURLSession存在ssl内层问题，开启后内层增长严重
@property (nonatomic, assign) BOOL enableDetectVolume;                  //是否检测录音音量的变化，开启后sdk会实时回掉音量变化
@property (nonatomic, assign) BOOL endRecognizeWhenDetectSilence;       //识别到静音是否结束识别，默认YES
@property (nonatomic, assign) float silenceDetectDuration;              //最大静音时间阈值、单位秒，超过silenceDetectDuration时间不说话则为静音
@property (nonatomic, assign) NSInteger sliceTime;                      //分片时间, 此参数影响语音分片长度, 默认600ms

/**
 * 初始化方法
 * @param appid     腾讯云appId     基本概念见https://cloud.tencent.com/document/product/441/6194
 * @param secretId  腾讯云secretId  基本概念见https://cloud.tencent.com/document/product/441/6194
 * @param secretKey 腾讯云secretKey 基本概念见https://cloud.tencent.com/document/product/441/6194
 * @param projectId 腾讯云projectId 基本概念见https://cloud.tencent.com/document/product/441/6194
 */
- (instancetype)initWithAppId:(NSString *)appid
                     secretId:(NSString *)secretId
                    secretKey:(NSString *)secretKey
                    projectId:(NSString *)projectId;

@end

NS_ASSUME_NONNULL_END
